#ifndef __alrms_h__
#define __alrms_h__
/* ==================================================================== */
/* Copyright (C) Olsonet Communications, 2014                           */
/* All rights reserved.                                                 */
/* ==================================================================== */

void set_alrm (word a);
void clr_alrm ();

//+++ alrms.cc

#endif
