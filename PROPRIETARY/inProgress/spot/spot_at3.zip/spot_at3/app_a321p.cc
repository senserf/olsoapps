/* ==================================================================== */
/* Copyright (C) Olsonet Communications, 2014                           */
/* All rights reserved.                                                 */
/* ==================================================================== */

// I'm not sure if we have any bord-specific things here, other than oss, which
// is set in inout part

#include "root_peg.cc"