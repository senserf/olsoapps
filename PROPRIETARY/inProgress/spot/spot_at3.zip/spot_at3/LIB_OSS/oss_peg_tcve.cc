/* ==================================================================== */
/* Copyright (C) Olsonet Communications, 2002 - 2014                    */
/* All rights reserved.                                                 */
/* ==================================================================== */
#include "commons.h"
#include "vartypes.h"
#include "diag.h"
#include "tag_mgr.h"
#include "tarp.h"
#include "inout.h"
#include "tcvphys.h"
#include "phys_uart.h"

#include "tcve_insert.cc"

// This i/f follows the Alphanet reqs... with all imperfections there, mainly:
// no dbg, bad ack/nacks, no node type.

static void stats () {
	char * b = get_mem (8, NO);
	if (b == NULL)
		return;
	b[0] = 0x91;
	b[1] = 8+3;
	((address)b)[1] = local_host;
	((address)b)[1] = 0x0002;
	((address)b)[1] = master_host;
	_oss_out (b);
	
}

static void reply11 (char *pkt) {

	char *b;
	word len;

	len = tcv_left ((address)pkt);

	if (len < 6 || (b = get_mem (8, NO)) == NULL)
		return;

	b [0] = 0x91;
	b [1] = 8+3;

	((address)b) [1] = ((address)pkt) [1];
	((address)b) [2] = ((address)pkt) [2];
	((address)b) [3] = (((address)pkt) [2] == 0x0002) ?
		(local_host == master_host) : local_host;
	_oss_out (b);
}

static void sack (byte req, word add, Boolean ok) {
//
// Send an ACK to RENESAS
//
	char *b;

	if ((b = get_mem (5, NO)) == NULL)
		return;

	b [0] = (req | 0x80);
	b [1] = 5+3;

	((address)b) [1] = add;

	b [4] = ok ? 0x06 : 0x15;

	_oss_out (b);
}

// ============================================================================
// PG END temporary
// ============================================================================

static void byteout (byte typ, byte val) {
	char * cb = get_mem (5+3, NO);
	if (cb == NULL)
		return;
	cb[0] = typ;
	cb[1] = 8;
	((address)cb)[1] = local_host;
	cb[4] = val;
	_oss_out (cb);
}
	
///////////////// oss in ////////////////

/* no need for that here, but we could build appropriate structs here and
   call process_incoming() as fsm hear does for RF in.
*/

fsm mbeacon;
fsm looper;
fsm cmd_in {

	state START:
		stats ();

	state LISN: // LISTEN keyword??
		word l;
		char * b;
		char * ib = (char *) tcv_rnp (LISN, oss_fd);

		switch ((byte)(*ib)) {
			case 0x11:	// mutated 'get node'
				// PG
				// stats();
				reply11 (ib);
				break;

			case 0xFF: reset();

			case 0x12:	// set local_host or master_host (bad bad idea)
				if (ib[1] != 11) {
					// byteout (0x12+0x80, 0x15); // nack
					// PG
					sack (0x12, 0, NO);
					break;
				}
				switch (((address)ib)[2]) {
					case 0x0001:
						local_host = ((address)ib)[3];
						// byteout (0x12+0x80, 0x06); // ack
						// PG
Pack:
						sack (0x12, ((address)ib)[1], YES);
						break;
						
					case 0x0002:
						// PG
						if (local_host != ((address)ib)[3]) {
							// byteout (0x12+0x80, 0x15); // nack
							// PG
							goto Pack;
						}
						if (local_host == master_host) {
							// PG do nothing other than CK;
							// the beacons would be too
							// frequent
							goto Pack;
#if 0
							if (running (mbeacon)) {
								trigger (TRIG_MBEAC);
							} else {
								runfsm mbeacon;
							}
#endif
						} else {
							master_host = local_host;
							tarp_ctrl.param = 0xB0;
							tagList.block = YES;
							reset_tags();
							killall (looper);
							runfsm mbeacon;
							goto Pack;
						}
						// byteout (0x12+0x80, 0x06); // ack
						// PG
						break;
						
					default:
						// byteout (0x12+0x80, 0x15); // nack
						// PG
Nak:
						sack (0x12, ((address)ib)[1], NO);
				}
				break;

			case 0x41:
			case 0x42:
			case 0x43:
				if (*((word *)(ib +2)) != local_host) {
				    l = ib[1] -3 + sizeof(msgFwdType);

				    if ((b = get_mem (l, NO)) != NULL) {
						memset (b, 0, l);
						in_header(b, msg_type) = msg_fwd;
						in_header(b, rcv) = *((word *)(ib +2));
						in_fwd(b, ref) = (word)seconds();
						memcpy (b+sizeof(msgFwdType), ib, l - sizeof(msgFwdType));
						talk (b, l, TO_ALL);
						ufree (b);
				    } else {
						byteout (0x12+0x80, 0x15);
					}
				} else {
					byteout (0x12+0x80, 0x15);
				}
				break;

			default:
				trigger (TRIG_OSSIN);
				// acks, nacks, etc.
				app_diag_W ("ign cmd %x %x", ((address)ib)[0], ((address)ib)[1]); 
		}
		tcv_endp ((address)ib);
		proceed LISN;
}
///////////////////////////////

#define _ppp	(p + sizeof(pongDataType))
static void board_out (char * p, char * b) {

	// for boards other tham ap319, 320: just for fun
	switch (((pongDataType *)p)->btyp) {
		case BTYPE_CHRONOS:
		case BTYPE_CHRONOS_WHITE:
			b[11] = (byte)((((pongPloadType0 *)_ppp)->volt - 1000) >> 3);
			b[9] = (byte)((pongPloadType0 *)_ppp)->move_ago; // vy not
			b[14] = (byte)((pongPloadType0 *)_ppp)->move_nr;
			break;

		case BTYPE_AT_BASE:
			b[11] = (byte)((((pongPloadType2 *)_ppp)->volt - 1000) >> 3);
			b[9] = 9;
			b[14] = 14;
			break;
			
		case BTYPE_AT_BUT6:
			b[9] = ((pongPloadType3 *)_ppp)->glob;
			b[11] = (byte)((((pongPloadType3 *)_ppp)->volt - 1000) >> 3);
			b[14] = ((pongPloadType3 *)_ppp)->dial;
			break;

		case BTYPE_AT_BUT1:
			b[9] = 1;
			b[11] = (byte)((((pongPloadType4 *)_ppp)->volt - 1000) >> 3);
			b[14] = 0;
			break;
			
		case BTYPE_WARSAW:
			b[9] = (byte)((pongPloadType5 *)_ppp)->random_shit;
			b[11] = (byte)((((pongPloadType5 *)_ppp)->volt - 1000) >> 3);
			b[14] = (byte)((pongPloadType5 *)_ppp)->steady_shit;
			break;

		default:
			app_diag_W ("btyp %u", ((pongDataType *)p)->btyp);
	}
}
#undef _ppp

// this is the main out on the oss i/f, I don't know at all if this makes
// more sense than no generic i/f at all
// NO parameter sanitization
void oss_tx (char * b, word siz) {
	char *bu;
	Boolean incoming;

	// I'm not sure (now) what to do with these 2 spec. cases FIXME dupa
	// likely, we'll need a dbg i/f

	// allocated, freed after output
	if (siz == MAX_WORD) {
		app_diag_U (b);
		ufree (b);
		return;
	}
	if (siz == 0) { // copied for direct output
		app_diag_U (b);
		return;
	}

	// b[0] doesn't have to be msg_type; if not, must be off the enum
	switch (b[0]) {
		case msg_report:
			// incoming = in_header(b, rcv) == local_host ? YES : NO;
			bu = get_mem (16, NO);
			if (bu == NULL)
				return;
			
			bu[0] = 0x01;
			bu[1] = 16+3;
			((address)bu)[1] = local_host;
			((address)bu)[2] = in_header(b, snd) == 0 ? local_host : in_header(b, snd);
			((address)bu)[3] = in_report(b, tagid);
			bu[8] = ((pongDataType *)(b + sizeof(msgReportType)))->alrm_id;
			// board specific bu[9] = global flag
			bu[10] = ((pongDataType *)(b + sizeof(msgReportType)))->alrm_seq;
			// board-specific bu[11] = voltage
			bu[12] = in_report(b, rssi);
			bu[13] = ((pongDataType *)(b + sizeof(msgReportType)))->plev;
			// board-specific bu[14] = dial
			board_out (b + sizeof(msgReportType), bu); // sets board-specifics
			bu[15] = in_report(b, ago);
			
			_oss_out (bu);
			break;

	    case msg_reportAck:
// diag ("dupa reportAck processing disabled");
			break;

			bu = get_mem (4+2+1+1, NO); // dupa was +2
			if (bu == NULL)
				return;
			bu[0] = 0x81;
			bu[1] = 11;
			((address)bu)[1] = in_reportAck(b, tagid);
			((address)bu)[2] = in_reportAck(b, ref);
			bu[6] = tagList.alrms;
			bu[7] = tagList.evnts;
			_oss_out (bu);
			break;

	    case msg_fwd:
			incoming = in_header(b, snd) != 0 &&
				in_header(b, snd) != local_host;
			
			bu = get_mem (*(b+sizeof(msgFwdType) +1) -3, NO);
			if (bu == NULL)
				return;
				
			memcpy (bu, b+sizeof(msgFwdType), *(b +sizeof(msgFwdType) +1) -3);
			
			if (incoming)
				((address)bu)[1] = in_header(b, snd);
			else { // ok, I replace node addr with ref#, well, not now
				bu[0] += 0x80;
				((address)bu)[1] = local_host; // in_fwd(b, ref);
			}
			_oss_out (bu);
			break;

	    case msg_fwdAck:
		// dupa disabled fwdAck
			break;
			bu = get_mem (6, NO);
			if (bu == NULL)
				return;
			bu[0] = 0x44; // I've made it up
			bu[1] = 9;
			((address)bu)[1] = in_header(b, snd);
			((address)bu)[2] = in_fwd(b, ref);
			_oss_out (bu);
			break;

	    default:
			app_diag_S ("dupa unfinished?");
	}
}

