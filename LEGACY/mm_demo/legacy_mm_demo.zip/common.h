#ifndef	__tnp_common_h__
#define	__tnp_common_h__

#include "sysio.h"
#include "board.h"

void buildTagNode (data_no_t*);
void buildPegNode (data_no_t*);

#endif
